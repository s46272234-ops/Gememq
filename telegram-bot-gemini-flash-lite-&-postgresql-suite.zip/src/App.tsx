import React, { useState, useEffect } from 'react';
import { Navbar, TabType } from './components/Navbar.tsx';
import { TelegramSimulator } from './components/TelegramSimulator.tsx';
import { CodeExplorer } from './components/CodeExplorer.tsx';
import { PostgresExplorer } from './components/PostgresExplorer.tsx';
import { BotSettings } from './components/BotSettings.tsx';
import { DEFAULT_SYSTEM_INSTRUCTION } from './server/gemini.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('simulator');
  const [systemPrompt, setSystemPrompt] = useState<string>(DEFAULT_SYSTEM_INSTRUCTION);
  const [contextLimit, setContextLimit] = useState<number>(15);
  const [temperature, setTemperature] = useState<number>(0.7);

  const [isPollingActive, setIsPollingActive] = useState<boolean>(false);
  const [botUsername, setBotUsername] = useState<string | null>(null);
  const [messageCount, setMessageCount] = useState<number>(0);

  const refreshBotStatus = async () => {
    try {
      const res = await fetch('/api/telegram/status');
      const data = await res.json();
      setIsPollingActive(Boolean(data.isActive));
      setBotUsername(data.botUsername || null);
    } catch (err) {
      console.error('Failed to get bot status:', err);
    }
  };

  const refreshStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      setMessageCount(data.total_messages || 0);
    } catch (err) {
      console.error('Failed to get stats:', err);
    }
  };

  useEffect(() => {
    refreshBotStatus();
    refreshStats();

    // Check status periodically
    const interval = setInterval(() => {
      refreshBotStatus();
      refreshStats();
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isPollingActive={isPollingActive}
        botUsername={botUsername}
        messageCount={messageCount}
      />

      <main className="flex-1 flex flex-col min-h-0">
        {activeTab === 'simulator' && (
          <TelegramSimulator
            onMessageSent={refreshStats}
            systemPrompt={systemPrompt}
            contextLimit={contextLimit}
          />
        )}

        {activeTab === 'code' && <CodeExplorer />}

        {activeTab === 'database' && <PostgresExplorer />}

        {activeTab === 'settings' && (
          <BotSettings
            systemPrompt={systemPrompt}
            setSystemPrompt={setSystemPrompt}
            contextLimit={contextLimit}
            setContextLimit={setContextLimit}
            temperature={temperature}
            setTemperature={setTemperature}
            isPollingActive={isPollingActive}
            botUsername={botUsername}
            onPollingStatusChange={refreshBotStatus}
          />
        )}
      </main>
    </div>
  );
}
