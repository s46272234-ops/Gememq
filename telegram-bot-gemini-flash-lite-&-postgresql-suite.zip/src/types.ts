export interface TelegramUser {
  id: number;
  username?: string;
  first_name: string;
  last_name?: string;
  language_code?: string;
  created_at: string;
  last_active_at: string;
}

export interface TelegramChat {
  id: number;
  type: 'private' | 'group' | 'supergroup';
  title?: string;
  system_prompt?: string;
  context_limit: number;
  created_at: string;
  updated_at: string;
}

export interface TelegramMessage {
  id: number;
  chat_id: number;
  user_id: number;
  telegram_message_id: number;
  role: 'user' | 'model' | 'system';
  content: string;
  image_url?: string;
  token_count?: number;
  latency_ms?: number;
  created_at: string;
}

export interface ImageGenerationRecord {
  id: number;
  chat_id: number;
  user_id: number;
  prompt: string;
  image_data: string; // base64 or URL
  aspect_ratio: string;
  created_at: string;
}

export interface BotStats {
  total_users: number;
  total_chats: number;
  total_messages: number;
  total_images: number;
  avg_latency_ms: number;
  model_name: string;
}

export interface BotConfig {
  systemPrompt: string;
  temperature: number;
  contextLimit: number;
  modelName: string;
  imageModelName: string;
  telegramBotToken?: string;
  isPollingActive: boolean;
  botUsername?: string;
}
