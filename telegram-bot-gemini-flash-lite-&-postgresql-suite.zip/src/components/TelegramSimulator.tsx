import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Image as ImageIcon,
  Trash2,
  Sparkles,
  Bot,
  User,
  Zap,
  Info,
  Clock,
  Layers,
  Copy,
  Check,
  Download,
  Terminal,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { TelegramMessage, TelegramChat } from '../types.ts';

interface TelegramSimulatorProps {
  onMessageSent?: () => void;
  systemPrompt: string;
  contextLimit: number;
}

export const TelegramSimulator: React.FC<TelegramSimulatorProps> = ({
  onMessageSent,
  systemPrompt,
  contextLimit,
}) => {
  const [messages, setMessages] = useState<TelegramMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [showContextInspector, setShowContextInspector] = useState(false);
  const [selectedChatId, setSelectedChatId] = useState<number>(874192451);
  const [chats, setChats] = useState<TelegramChat[]>([]);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const loadChats = async () => {
    try {
      const res = await fetch('/api/chats');
      const data = await res.json();
      if (Array.isArray(data)) {
        setChats(data);
      }
    } catch (err) {
      console.error('Failed to load chats:', err);
    }
  };

  const loadMessages = async (chatId: number) => {
    try {
      const res = await fetch(`/api/chats/${chatId}/messages`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setMessages(data);
      }
    } catch (err) {
      console.error('Failed to load messages:', err);
    }
  };

  useEffect(() => {
    loadChats();
    loadMessages(selectedChatId);
  }, [selectedChatId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    setInputText('');

    const isImageCommand = text.startsWith('/image') || /^(нарисуй|создай картинку|сгенерируй фото|draw):/i.test(text);
    if (isImageCommand) {
      setIsGeneratingImage(true);
    }
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: selectedChatId,
          user_id: selectedChatId,
          content: text,
          systemInstruction: systemPrompt,
          contextLimit: contextLimit,
        }),
      });

      const data = await res.json();
      if (data.type === 'clear') {
        setMessages([]);
      } else {
        await loadMessages(selectedChatId);
        await loadChats();
      }

      if (onMessageSent) {
        onMessageSent();
      }
    } catch (err: any) {
      console.error('Error sending message:', err);
      // Append temporary error message
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          chat_id: selectedChatId,
          user_id: 0,
          telegram_message_id: 0,
          role: 'system',
          content: `⚠️ Ошибка: ${err.message || 'Сбой соединения'}`,
          created_at: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsLoading(false);
      setIsGeneratingImage(false);
    }
  };

  const handleClearContext = async () => {
    if (confirm('Очистить историю сообщений текущего диалога в PostgreSQL?')) {
      await handleSendMessage('/clear');
    }
  };

  const handleCopyCode = (text: string, id: number) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Extract recent context window messages (what is sent to Gemini Flash Lite)
  const contextWindowMessages = messages.slice(-contextLimit);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-4rem)] bg-slate-950 text-slate-100 overflow-hidden">
      {/* Sidebar: Chats & Context Info */}
      <div className="w-full lg:w-72 bg-slate-900/90 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-sky-400" />
            <span className="font-semibold text-sm">Чаты Telegram</span>
          </div>
          <button
            onClick={() => setShowContextInspector(!showContextInspector)}
            title="Инспектор контекста памяти LLM"
            className={`p-1.5 rounded-md text-xs flex items-center gap-1 border transition-colors ${
              showContextInspector
                ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                : 'text-slate-400 border-slate-700 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="text-[11px] hidden sm:inline">Контекст</span>
          </button>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {chats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`w-full text-left p-2.5 rounded-lg transition-all flex items-start gap-2.5 ${
                selectedChatId === chat.id
                  ? 'bg-sky-600/20 text-white border border-sky-500/30'
                  : 'text-slate-300 hover:bg-slate-800/60'
              }`}
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white font-bold text-xs shrink-0 mt-0.5">
                {chat.title?.slice(0, 2).toUpperCase() || 'TG'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-xs truncate">{chat.title || `Чат ${chat.id}`}</span>
                  <span className="text-[10px] text-slate-500">ID: {chat.id}</span>
                </div>
                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                  {(chat as any).lastMessage || 'Нет сообщений'}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700/50">
                    {(chat as any).messageCount || 0} сообщ.
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Database & Memory Status */}
        <div className="p-3 bg-slate-900 border-t border-slate-800 text-xs text-slate-400 space-y-2">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" /> Модель:
            </span>
            <span className="font-mono text-[11px] text-sky-400 font-semibold">gemini-3.1-flash-lite</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-400" /> Окно контекста:
            </span>
            <span className="font-medium text-slate-300">{contextLimit} сообщ. (PostgreSQL)</span>
          </div>
          <button
            onClick={handleClearContext}
            className="w-full mt-1 py-1.5 px-3 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 text-xs flex items-center justify-center gap-1.5 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Очистить контекст (/clear)</span>
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Telegram Chat Header */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-md">
                <Bot className="w-5 h-5" />
              </div>
              <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="font-semibold text-sm sm:text-base text-white">Gemini Flash Lite Bot</h2>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-400 font-medium">bot</span>
              </div>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                online • PostgreSQL Memory Active
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowContextInspector(!showContextInspector)}
              className="px-2.5 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              {showContextInspector ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">
                {showContextInspector ? 'Скрыть контекст' : 'Инспектор контекста'}
              </span>
            </button>
            <button
              onClick={() => loadMessages(selectedChatId)}
              title="Обновить историю сообщений"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Context Window Inspector Drawer (when toggled) */}
        {showContextInspector && (
          <div className="bg-slate-900/95 border-b border-sky-500/30 p-3 max-h-56 overflow-y-auto text-xs animate-in slide-in-from-top duration-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-sky-400 flex items-center gap-1.5">
                <Layers className="w-4 h-4" />
                Текущий контекст диалога в PostgreSQL ({contextWindowMessages.length} из {contextLimit} реплик)
              </span>
              <span className="text-[11px] text-slate-400">
                Передается в Gemini 3.1 Flash Lite при каждом сообщении
              </span>
            </div>
            {contextWindowMessages.length === 0 ? (
              <p className="text-slate-500 italic">Контекст пуст. Напишите сообщение, чтобы начать историю.</p>
            ) : (
              <div className="space-y-1.5 font-mono text-[11px]">
                {contextWindowMessages.map((m, idx) => (
                  <div
                    key={idx}
                    className={`p-1.5 rounded flex items-start gap-2 ${
                      m.role === 'model'
                        ? 'bg-slate-800/80 text-sky-200 border-l-2 border-sky-400'
                        : 'bg-slate-800/50 text-slate-200 border-l-2 border-emerald-400'
                    }`}
                  >
                    <span className="font-bold shrink-0 uppercase text-[10px] w-12">
                      [{m.role}]:
                    </span>
                    <span className="truncate flex-1">{m.content}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Telegram Chat Wallpaper & Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#0e1621] bg-radial-[at_top_right] from-slate-900/60 to-transparent">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto p-6 text-slate-400">
              <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 mb-4 shadow-inner">
                <Sparkles className="w-8 h-8" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Telegram AI Бот готов к диалогу</h3>
              <p className="text-xs text-slate-400 mb-6 leading-relaxed">
                Напишите любой вопрос, протестируйте контекстную память диалога или сгенерируйте изображение командой <code className="text-sky-300 bg-slate-800 px-1.5 py-0.5 rounded">/image</code>.
              </p>
              <div className="flex flex-wrap gap-2 justify-center">
                <button
                  onClick={() => handleSendMessage('/start')}
                  className="px-3 py-1.5 rounded-lg bg-sky-600/30 hover:bg-sky-600/50 text-sky-300 text-xs border border-sky-500/40"
                >
                  🚀 Отправить /start
                </button>
                <button
                  onClick={() => handleSendMessage('Расскажи о себе и своих возможностях')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700"
                >
                  💬 Кто ты?
                </button>
                <button
                  onClick={() => handleSendMessage('/image футуристический летающий автомобиль над ночным Токио')}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs border border-indigo-500/40"
                >
                  🎨 /image Токио будущего
                </button>
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === 'user';
              const isSystem = msg.role === 'system';

              if (isSystem) {
                return (
                  <div key={msg.id} className="flex justify-center">
                    <div className="bg-slate-800/80 text-amber-300 border border-amber-500/30 text-xs px-3 py-1.5 rounded-full shadow-sm max-w-md text-center">
                      {msg.content}
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shrink-0 mb-1 shadow">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] sm:max-w-xl rounded-2xl p-3 sm:p-4 shadow-md transition-all ${
                      isUser
                        ? 'bg-[#2b5278] text-white rounded-br-xs'
                        : 'bg-[#182533] text-slate-100 rounded-bl-xs border border-slate-700/60'
                    }`}
                  >
                    {/* Image Attachment (if any) */}
                    {msg.image_url && (
                      <div className="mb-2.5 rounded-xl overflow-hidden border border-slate-700/80 bg-black/40">
                        <img
                          src={msg.image_url}
                          alt="Generated AI Art"
                          className="w-full max-h-80 object-cover cursor-pointer hover:opacity-95 transition-opacity"
                          onClick={() => setSelectedImage(msg.image_url || null)}
                        />
                        <div className="p-2 bg-slate-900/90 flex items-center justify-between text-[11px] text-slate-300">
                          <span className="flex items-center gap-1 text-sky-400">
                            <Sparkles className="w-3 h-3" /> Gemini 3.1 Flash Lite Image
                          </span>
                          <a
                            href={msg.image_url}
                            download="gemini-art.png"
                            className="flex items-center gap-1 hover:text-white transition-colors"
                          >
                            <Download className="w-3.5 h-3.5" /> Скачать
                          </a>
                        </div>
                      </div>
                    )}

                    {/* Content text */}
                    <div className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                      {msg.content}
                    </div>

                    {/* Metadata Footer: Latency, Token Count, Timestamp */}
                    <div
                      className={`mt-2 pt-1 flex items-center justify-between text-[10px] border-t ${
                        isUser ? 'border-sky-400/20 text-sky-200/70' : 'border-slate-700/50 text-slate-400'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        {msg.latency_ms !== undefined && msg.latency_ms > 0 && (
                          <span className="flex items-center gap-0.5 text-emerald-400 font-mono">
                            <Zap className="w-2.5 h-2.5" />
                            {msg.latency_ms} ms
                          </span>
                        )}
                        {msg.token_count !== undefined && (
                          <span className="text-slate-400 font-mono">
                            {msg.token_count} токенов
                          </span>
                        )}
                        {!isUser && (
                          <button
                            onClick={() => handleCopyCode(msg.content, msg.id)}
                            className="hover:text-white transition-colors"
                            title="Скопировать текст"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-1 font-mono">
                        <Clock className="w-2.5 h-2.5" />
                        <span>
                          {new Date(msg.created_at).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>
                  </div>

                  {isUser && (
                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-slate-200 shrink-0 mb-1">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Typing / Generating Indicator */}
          {isLoading && (
            <div className="flex items-end gap-2 justify-start">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shrink-0 shadow">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-[#182533] border border-slate-700/60 rounded-2xl rounded-bl-xs px-4 py-3 text-xs text-slate-300 flex items-center gap-3">
                {isGeneratingImage ? (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
                    <span>Gemini генерирует изображение по вашему промпту...</span>
                  </>
                ) : (
                  <>
                    <div className="flex gap-1 items-center">
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                    </div>
                    <span>Gemini 3.1 Flash Lite думает...</span>
                  </>
                )}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Command Pills */}
        <div className="bg-slate-900/90 px-4 py-1.5 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs shrink-0">
          <span className="text-[11px] text-slate-400 font-semibold shrink-0">Быстрые команды:</span>
          <button
            onClick={() => handleSendMessage('/start')}
            className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 shrink-0 transition-colors"
          >
            /start
          </button>
          <button
            onClick={() => handleSendMessage('/help')}
            className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 shrink-0 transition-colors"
          >
            /help
          </button>
          <button
            onClick={() => handleSendMessage('/image футуристический кот в неоновых очках за компьютером')}
            className="px-2.5 py-1 rounded-md bg-indigo-950/60 hover:bg-indigo-900/60 text-indigo-300 border border-indigo-700/40 shrink-0 transition-colors flex items-center gap-1"
          >
            <ImageIcon className="w-3 h-3" /> /image Кот киберпанк
          </button>
          <button
            onClick={() => handleSendMessage('/stats')}
            className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 shrink-0 transition-colors"
          >
            /stats
          </button>
          <button
            onClick={() => handleSendMessage('/model')}
            className="px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-slate-700 shrink-0 transition-colors"
          >
            /model
          </button>
          <button
            onClick={handleClearContext}
            className="px-2.5 py-1 rounded-md bg-red-950/40 hover:bg-red-900/40 text-red-300 border border-red-800/40 shrink-0 transition-colors"
          >
            /clear
          </button>
        </div>

        {/* Input Bar */}
        <div className="bg-slate-900 border-t border-slate-800 p-3 sm:p-4 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2 max-w-4xl mx-auto"
          >
            <button
              type="button"
              onClick={() => {
                setInputText('/image ');
              }}
              title="Сгенерировать картинку (/image)"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
            >
              <ImageIcon className="w-5 h-5 text-indigo-400" />
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Напишите сообщение боту (или /image для генерации картинки)..."
              disabled={isLoading}
              className="flex-1 bg-slate-800/90 text-white placeholder-slate-400 px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent text-sm"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white font-medium text-sm flex items-center gap-1.5 shadow-md shadow-sky-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              <Send className="w-4 h-4" />
              <span className="hidden sm:inline">Отправить</span>
            </button>
          </form>
        </div>
      </div>

      {/* Image Modal Lightbox */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-3xl w-full max-h-[90vh] bg-slate-900 rounded-2xl overflow-hidden border border-slate-700 shadow-2xl p-2" onClick={(e) => e.stopPropagation()}>
            <img src={selectedImage} alt="Enlarged Art" className="w-full h-auto max-h-[80vh] object-contain rounded-xl" />
            <div className="mt-3 px-2 flex justify-between items-center text-xs text-slate-300">
              <span>Сгенерировано: gemini-3.1-flash-lite-image</span>
              <div className="flex gap-2">
                <a
                  href={selectedImage}
                  download="gemini-art.png"
                  className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" /> Скачать в полном качестве
                </a>
                <button
                  onClick={() => setSelectedImage(null)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  Закрыть
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
