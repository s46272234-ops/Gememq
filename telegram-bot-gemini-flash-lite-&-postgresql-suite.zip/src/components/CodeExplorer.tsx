import React, { useState, useEffect } from 'react';
import {
  FileCode,
  Copy,
  Check,
  Download,
  Terminal,
  FileText,
  Database,
  Cpu,
  Layers,
  CheckCircle2,
  ExternalLink,
  FolderTree
} from 'lucide-react';
import { CODE_TEMPLATES, CodeFile } from '../server/codeTemplates.ts';

export const CodeExplorer: React.FC = () => {
  const [files, setFiles] = useState<Record<string, CodeFile>>(CODE_TEMPLATES);
  const [selectedFileName, setSelectedFileName] = useState<string>('bot.ts');
  const [copied, setCopied] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  useEffect(() => {
    fetch('/api/code/templates')
      .then((res) => res.json())
      .then((data) => {
        if (data && Object.keys(data).length > 0) {
          setFiles(data);
        }
      })
      .catch((err) => console.error('Failed to load templates:', err));
  }, []);

  const activeFile = files[selectedFileName] || CODE_TEMPLATES['bot.ts'];

  const handleCopyCurrent = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCurrent = () => {
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = activeFile.name.replace(/\s*\(.*\)/, '');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleCopyAllProject = () => {
    let combined = '';
    for (const [key, f] of Object.entries(files)) {
      combined += `\n/* ====================================================\n * FILE: ${f.path}\n * ==================================================== */\n\n${f.content}\n\n`;
    }
    navigator.clipboard.writeText(combined);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2500);
  };

  const getFileIcon = (name: string) => {
    if (name.endsWith('.sql')) return <Database className="w-4 h-4 text-emerald-400" />;
    if (name.endsWith('.ts') || name.endsWith('.js')) return <FileCode className="w-4 h-4 text-sky-400" />;
    if (name.endsWith('.yml') || name.endsWith('.yaml')) return <Cpu className="w-4 h-4 text-amber-400" />;
    if (name.includes('Docker')) return <Layers className="w-4 h-4 text-blue-400" />;
    return <FileText className="w-4 h-4 text-slate-400" />;
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-4rem)] bg-slate-950 text-slate-100 overflow-hidden">
      {/* Left File Tree Sidebar */}
      <div className="w-full lg:w-80 bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-sky-400" />
            <h2 className="font-semibold text-sm">Файлы проекта бота</h2>
          </div>
          <button
            onClick={handleCopyAllProject}
            className="text-xs px-2.5 py-1 rounded-md bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/20 flex items-center gap-1 transition-colors"
            title="Скопировать все файлы сразу"
          >
            {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedAll ? 'Скопировано!' : 'Все файлы'}</span>
          </button>
        </div>

        {/* File List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {Object.entries(files).map(([key, file]) => (
            <button
              key={key}
              onClick={() => setSelectedFileName(key)}
              className={`w-full text-left px-3 py-2.5 rounded-lg text-xs font-mono transition-all flex items-center gap-2.5 ${
                selectedFileName === key
                  ? 'bg-sky-600/20 text-sky-300 border border-sky-500/40 font-semibold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              {getFileIcon(file.name)}
              <div className="flex-1 min-w-0">
                <span className="truncate block">{file.name}</span>
                <span className="text-[10px] text-slate-500 font-sans block truncate">
                  {file.description.slice(0, 45)}...
                </span>
              </div>
            </button>
          ))}
        </div>

        {/* Deploy Quick Highlights */}
        <div className="p-3 bg-slate-950/60 border-t border-slate-800 text-[11px] text-slate-400 space-y-1.5">
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5" /> Готово к деплою на любой VPS / Docker
          </div>
          <p className="text-slate-500 text-[10px]">
            Модель: <strong>gemini-3.1-flash-lite</strong> • БД: <strong>PostgreSQL 16</strong>
          </p>
        </div>
      </div>

      {/* Main Code View Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0d1117]">
        {/* File Header Bar */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            {getFileIcon(activeFile.name)}
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-semibold text-white">{activeFile.path}</span>
                <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {activeFile.language}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-xl">{activeFile.description}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopyCurrent}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Скопировано!' : 'Копировать'}</span>
            </button>

            <button
              onClick={handleDownloadCurrent}
              className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-medium flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Скачать</span>
            </button>
          </div>
        </div>

        {/* Architecture Pipeline Explanation Card */}
        <div className="bg-slate-900/60 border-b border-slate-800/80 px-4 py-2 text-xs flex items-center gap-4 overflow-x-auto text-slate-400 shrink-0">
          <span className="font-semibold text-slate-300 shrink-0">Архитектура:</span>
          <div className="flex items-center gap-2 shrink-0 font-mono text-[11px]">
            <span className="px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20">Telegram User</span>
            <span>➔</span>
            <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">bot.ts (GrammY)</span>
            <span>➔</span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">PostgreSQL (SELECT 15 msgs)</span>
            <span>➔</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">gemini-3.1-flash-lite</span>
            <span>➔</span>
            <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">INSERT tg_messages</span>
          </div>
        </div>

        {/* Code Content with Line Numbers */}
        <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed select-text">
          <pre className="text-slate-200 font-mono whitespace-pre">
            <code>
              {activeFile.content.split('\n').map((line, index) => (
                <div key={index} className="table-row hover:bg-slate-800/40">
                  <span className="table-cell select-none text-slate-600 text-right pr-4 pl-2 py-0.2 w-10 text-[11px]">
                    {index + 1}
                  </span>
                  <span className="table-cell pl-2 py-0.2 whitespace-pre break-all">
                    {line}
                  </span>
                </div>
              ))}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
};
