import React, { useState, useEffect } from 'react';
import {
  Database,
  Table,
  Play,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Layers,
  FileCode,
  HardDrive,
  Users,
  MessageSquare,
  Image as ImageIcon
} from 'lucide-react';

interface TableMeta {
  name: string;
  rowCount: number;
  description: string;
}

export const PostgresExplorer: React.FC = () => {
  const [tables, setTables] = useState<TableMeta[]>([]);
  const [sampleData, setSampleData] = useState<Record<string, any[]>>({});
  const [activeTable, setActiveTable] = useState<string>('tg_messages');
  const [sqlQuery, setSqlQuery] = useState<string>('SELECT * FROM tg_messages ORDER BY created_at DESC LIMIT 10;');
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    rows: any[];
    rowCount: number;
    executionTimeMs: number;
  } | null>(null);
  const [queryError, setQueryError] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  const loadTables = async () => {
    try {
      const res = await fetch('/api/db/tables');
      const data = await res.json();
      if (data.tables) {
        setTables(data.tables);
        setSampleData(data.sampleData || {});
      }
    } catch (err) {
      console.error('Failed to load DB tables:', err);
    }
  };

  useEffect(() => {
    loadTables();
    runQuery(sqlQuery);
  }, []);

  const runQuery = async (queryToRun?: string) => {
    const q = (queryToRun || sqlQuery).trim();
    if (!q) return;

    setIsExecuting(true);
    setQueryError(null);

    try {
      const res = await fetch('/api/db/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: q }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ошибка выполнения SQL');
      }

      setQueryResult(data);
    } catch (err: any) {
      setQueryError(err.message || 'Ошибка SQL запроса');
      setQueryResult(null);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleSelectTablePreset = (tableName: string) => {
    setActiveTable(tableName);
    const newSql = `SELECT * FROM ${tableName} ORDER BY ${tableName === 'tg_users' ? 'last_active_at' : 'created_at'} DESC LIMIT 15;`;
    setSqlQuery(newSql);
    runQuery(newSql);
  };

  const currentTableRows = (sampleData[activeTable] || []).filter((row) => {
    if (!searchFilter.trim()) return true;
    const str = JSON.stringify(row).toLowerCase();
    return str.includes(searchFilter.toLowerCase());
  });

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] bg-slate-950 text-slate-100 overflow-hidden">
      {/* Top Banner & Stats */}
      <div className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-wrap items-center justify-between gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">PostgreSQL Explorer</h2>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Схема синхронизирована
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Хранилище контекста диалогов, истории сообщений и сгенерированных артов Telegram
            </p>
          </div>
        </div>

        {/* Quick DB Summary Badges */}
        <div className="flex items-center gap-3 text-xs">
          {tables.map((t) => (
            <button
              key={t.name}
              onClick={() => handleSelectTablePreset(t.name)}
              className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 transition-all ${
                activeTable === t.name
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-sm'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
            >
              {t.name === 'tg_messages' && <MessageSquare className="w-3.5 h-3.5" />}
              {t.name === 'tg_chats' && <Layers className="w-3.5 h-3.5" />}
              {t.name === 'tg_users' && <Users className="w-3.5 h-3.5" />}
              {t.name === 'image_generations' && <ImageIcon className="w-3.5 h-3.5" />}
              <span className="font-mono">{t.name}</span>
              <span className="bg-slate-900 px-1.5 py-0.2 rounded text-[10px] text-slate-300">
                {t.rowCount}
              </span>
            </button>
          ))}
          <button
            onClick={() => loadTables()}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
            title="Обновить данные таблиц"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Grid: SQL Query Console & Table Data */}
      <div className="flex-1 flex flex-col min-h-0 p-4 sm:p-6 gap-4 overflow-y-auto">
        {/* SQL Console Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm shrink-0">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Play className="w-3.5 h-3.5 text-emerald-400" /> Интерактивная SQL консоль PostgreSQL
            </span>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Быстрые запросы:</span>
              <button
                onClick={() => {
                  const q = 'SELECT * FROM tg_messages ORDER BY created_at DESC LIMIT 10;';
                  setSqlQuery(q);
                  runQuery(q);
                }}
                className="text-[11px] text-sky-400 hover:underline font-mono"
              >
                Последние сообщения
              </button>
              <span className="text-slate-600">•</span>
              <button
                onClick={() => {
                  const q = 'SELECT * FROM tg_users;';
                  setSqlQuery(q);
                  runQuery(q);
                }}
                className="text-[11px] text-sky-400 hover:underline font-mono"
              >
                Все юзеры
              </button>
              <span className="text-slate-600">•</span>
              <button
                onClick={() => {
                  const q = 'SELECT * FROM image_generations ORDER BY created_at DESC;';
                  setSqlQuery(q);
                  runQuery(q);
                }}
                className="text-[11px] text-sky-400 hover:underline font-mono"
              >
                Картинки
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <textarea
              value={sqlQuery}
              onChange={(e) => setSqlQuery(e.target.value)}
              rows={2}
              className="flex-1 bg-slate-950 text-emerald-400 font-mono text-xs p-3 rounded-lg border border-slate-700/80 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              placeholder="Введите SQL запрос (например: SELECT * FROM tg_messages;)..."
            />
            <button
              onClick={() => runQuery()}
              disabled={isExecuting}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 disabled:opacity-50 transition-colors shrink-0"
            >
              {isExecuting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
              <span>Выполнить</span>
            </button>
          </div>

          {queryError && (
            <div className="mt-2.5 p-2.5 bg-red-950/40 border border-red-500/30 rounded-lg text-xs text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{queryError}</span>
            </div>
          )}

          {queryResult && !queryError && (
            <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-3">
              <span className="text-emerald-400 font-medium">✓ Выполнено успешно</span>
              <span>Строк: {queryResult.rowCount}</span>
              <span>Время: {queryResult.executionTimeMs} ms</span>
            </div>
          )}
        </div>

        {/* Tabular Result Viewer */}
        <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl flex flex-col min-h-64 overflow-hidden shadow-sm">
          {/* Table Toolbar */}
          <div className="p-3 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-900/80">
            <div className="flex items-center gap-2">
              <Table className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-xs font-mono text-slate-200">
                Результаты запроса ({queryResult?.rows?.length || 0} записей)
              </span>
            </div>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Фильтр по строкам..."
                className="bg-slate-950 text-slate-300 text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-700/80 focus:outline-none focus:ring-1 focus:ring-emerald-500 w-48 sm:w-64"
              />
            </div>
          </div>

          {/* Table Render */}
          <div className="flex-1 overflow-auto">
            {queryResult && queryResult.rows && queryResult.rows.length > 0 ? (
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-950 text-slate-400 sticky top-0 border-b border-slate-800">
                  <tr>
                    {queryResult.columns.map((col) => (
                      <th key={col} className="p-3 font-semibold uppercase tracking-wider text-[11px]">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {queryResult.rows
                    .filter((row) => {
                      if (!searchFilter.trim()) return true;
                      return JSON.stringify(row).toLowerCase().includes(searchFilter.toLowerCase());
                    })
                    .map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
                        {queryResult.columns.map((col) => {
                          const val = row[col];
                          const isRole = col === 'role';
                          const isDate = col.includes('created_at') || col.includes('last_active_at') || col.includes('updated_at');

                          return (
                            <td key={col} className="p-3 text-slate-300 max-w-md truncate">
                              {isRole ? (
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                    val === 'model'
                                      ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30'
                                      : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                  }`}
                                >
                                  {val}
                                </span>
                              ) : isDate && val ? (
                                <span className="text-slate-400 text-[11px]">
                                  {new Date(val).toLocaleString('ru-RU')}
                                </span>
                              ) : typeof val === 'object' && val !== null ? (
                                JSON.stringify(val)
                              ) : (
                                String(val ?? '')
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                </tbody>
              </table>
            ) : (
              <div className="h-full flex flex-col items-center justify-center p-8 text-slate-500 text-xs text-center">
                <Database className="w-8 h-8 text-slate-600 mb-2" />
                <p>Нет записей или запрос не вернул данных</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Отправьте сообщение в симуляторе бота, чтобы наполнить таблицу tg_messages
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
