import React, { useState } from 'react';
import {
  Settings,
  Bot,
  Zap,
  Play,
  Square,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Key,
  Shield,
  Layers,
  Sparkles,
  Database,
  ExternalLink,
  Sliders
} from 'lucide-react';

interface BotSettingsProps {
  systemPrompt: string;
  setSystemPrompt: (prompt: string) => void;
  contextLimit: number;
  setContextLimit: (limit: number) => void;
  temperature: number;
  setTemperature: (temp: number) => void;
  isPollingActive: boolean;
  botUsername?: string | null;
  onPollingStatusChange: () => void;
}

export const BotSettings: React.FC<BotSettingsProps> = ({
  systemPrompt,
  setSystemPrompt,
  contextLimit,
  setContextLimit,
  temperature,
  setTemperature,
  isPollingActive,
  botUsername,
  onPollingStatusChange,
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [isStarting, setIsStarting] = useState(false);
  const [pollingError, setPollingError] = useState<string | null>(null);
  const [pollingSuccess, setPollingSuccess] = useState<string | null>(null);
  const [copiedWebhook, setCopiedWebhook] = useState(false);

  const webhookUrl = `${window.location.origin}/api/telegram/webhook`;

  const handleStartPolling = async () => {
    if (!tokenInput.trim() && !isPollingActive) {
      setPollingError('Введите токен бота от @BotFather');
      return;
    }

    setIsStarting(true);
    setPollingError(null);
    setPollingSuccess(null);

    try {
      const res = await fetch('/api/telegram/start-polling', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tokenInput.trim() }),
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.message || 'Ошибка запуска бота');
      }
      setPollingSuccess(`Бот @${data.username} успешно запущен в реальном Telegram!`);
      onPollingStatusChange();
    } catch (err: any) {
      setPollingError(err.message || 'Не удалось запустить polling');
    } finally {
      setIsStarting(false);
    }
  };

  const handleStopPolling = async () => {
    setIsStarting(true);
    setPollingError(null);
    try {
      await fetch('/api/telegram/stop-polling', { method: 'POST' });
      setPollingSuccess('Бот остановлен');
      onPollingStatusChange();
    } catch (err: any) {
      setPollingError(err.message);
    } finally {
      setIsStarting(false);
    }
  };

  const handleApplyPreset = (presetText: string) => {
    setSystemPrompt(presetText);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-6 text-slate-100 overflow-y-auto">
      {/* 1. Live Telegram Runner Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">Живой запуск Telegram-бота (Long Polling)</h3>
                {isPollingActive ? (
                  <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5 animate-pulse">
                    ● В сети @{botUsername}
                  </span>
                ) : (
                  <span className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                    Остановлен
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                Подключите ваш токен от <a href="https://t.me/BotFather" target="_blank" rel="noreferrer" className="text-sky-400 underline inline-flex items-center gap-0.5">@BotFather <ExternalLink className="w-2.5 h-2.5" /></a> и бот начнет отвечать в реальном Telegram
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Telegram Bot Token:
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Key className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="password"
                  value={tokenInput}
                  onChange={(e) => setTokenInput(e.target.value)}
                  placeholder="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"
                  className="w-full bg-slate-950 text-white font-mono text-xs pl-9 pr-4 py-2.5 rounded-xl border border-slate-700/80 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {!isPollingActive ? (
                <button
                  onClick={handleStartPolling}
                  disabled={isStarting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 disabled:opacity-50 transition-all shrink-0"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>{isStarting ? 'Подключение...' : 'Запустить бота в Telegram'}</span>
                </button>
              ) : (
                <button
                  onClick={handleStopPolling}
                  disabled={isStarting}
                  className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-red-600/20 disabled:opacity-50 transition-all shrink-0"
                >
                  <Square className="w-4 h-4 fill-current" />
                  <span>{isStarting ? 'Остановка...' : 'Остановить бота'}</span>
                </button>
              )}
            </div>
          </div>

          {pollingError && (
            <div className="p-3 bg-red-950/40 border border-red-500/30 rounded-xl text-xs text-red-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{pollingError}</span>
            </div>
          )}

          {pollingSuccess && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{pollingSuccess}</span>
            </div>
          )}

          {/* Webhook Option for production deployment */}
          <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-semibold text-slate-300 block">Webhook URL (для продакшна на сервере):</span>
              <code className="text-sky-400 font-mono text-[11px] break-all">{webhookUrl}</code>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText(webhookUrl);
                setCopiedWebhook(true);
                setTimeout(() => setCopiedWebhook(false), 2000);
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 flex items-center gap-1.5 shrink-0 transition-colors"
            >
              {copiedWebhook ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedWebhook ? 'Скопировано' : 'Копировать URL'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. AI Model & Dialog Memory Settings */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-md">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Параметры Gemini 3.1 Flash Lite</h3>
            <p className="text-xs text-slate-400">
              Настройка языковой модели, глубины контекста в PostgreSQL и системного промпта
            </p>
          </div>
        </div>

        {/* Model Specs Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400">Модель диалогов:</span>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Flash Lite
              </span>
            </div>
            <div className="font-mono text-sm font-semibold text-white">gemini-3.1-flash-lite</div>
            <p className="text-[11px] text-slate-500 mt-1">
              Сверхбыстрая генерация с поддержкой контекста, минимальной задержкой и точным форматированием.
            </p>
          </div>

          <div className="p-3.5 bg-slate-950/60 border border-slate-800 rounded-xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400">Модель генерации картинок:</span>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                Image Gen
              </span>
            </div>
            <div className="font-mono text-sm font-semibold text-white">gemini-3.1-flash-lite-image</div>
            <p className="text-[11px] text-slate-500 mt-1">
              Создание изображений по командам /image &lt;описание&gt; прямо в чате Telegram.
            </p>
          </div>
        </div>

        {/* Sliders: Context Window & Temperature */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                Окно памяти контекста (PostgreSQL):
              </span>
              <span className="font-mono font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
                {contextLimit} сообщений
              </span>
            </div>
            <input
              type="range"
              min={3}
              max={40}
              step={1}
              value={contextLimit}
              onChange={(e) => setContextLimit(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
            />
            <p className="text-[11px] text-slate-500 mt-1.5">
              Количество последних реплик из таблицы <code className="text-slate-400 font-mono">tg_messages</code>, отправляемых в запрос Gemini.
            </p>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                Креативность (Temperature):
              </span>
              <span className="font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                {temperature}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <p className="text-[11px] text-slate-500 mt-1.5">
              0.2 — строгие и точные ответы, 0.7 — сбалансированные, 1.0 — максимально творческие.
            </p>
          </div>
        </div>

        {/* System Prompt / Persona */}
        <div className="pt-2">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <label className="text-xs font-semibold text-slate-300">
              Системный промпт (Инструкция для бота):
            </label>
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-[11px] text-slate-400">Шаблоны персон:</span>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Ты — полезный, дружелюбный и быстрый Telegram-бот ассистент на модели Gemini 3.1 Flash Lite. Отвечай понятно, вежливо и красиво форматируй ответы в Markdown.'
                  )
                }
                className="text-[11px] text-sky-400 hover:underline"
              >
                Дружелюбный
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Ты — Senior Software Engineer и техлид. Отвечай профессионально, приводи примеры кода на TypeScript, Python, SQL. Используй блоки кода с подсветкой синтаксиса.'
                  )
                }
                className="text-[11px] text-sky-400 hover:underline"
              >
                Программист
              </button>
              <span className="text-slate-600">•</span>
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Ты — супер-краткий Telegram бот. Отвечай максимально лаконично, без лишней воды, по существу в 1-3 предложения.'
                  )
                }
                className="text-[11px] text-sky-400 hover:underline"
              >
                Лаконичный
              </button>
            </div>
          </div>
          <textarea
            value={systemPrompt}
            onChange={(e) => setSystemPrompt(e.target.value)}
            rows={4}
            className="w-full bg-slate-950 text-slate-200 text-xs p-3.5 rounded-xl border border-slate-700/80 focus:outline-none focus:ring-2 focus:ring-sky-500 leading-relaxed font-mono"
            placeholder="Опишите характер, правила ответов и форматирование бота..."
          />
        </div>
      </div>
    </div>
  );
};
