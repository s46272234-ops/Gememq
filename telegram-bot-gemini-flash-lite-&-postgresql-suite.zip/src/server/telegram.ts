import { dbService } from './db.ts';
import { askGeminiFlashLite, generateGeminiImage, DEFAULT_SYSTEM_INSTRUCTION } from './gemini.ts';

interface PollingState {
  isActive: boolean;
  token: string | null;
  botUsername: string | null;
  lastUpdateId: number;
  abortController: AbortController | null;
}

const state: PollingState = {
  isActive: false,
  token: process.env.TELEGRAM_BOT_TOKEN || null,
  botUsername: null,
  lastUpdateId: 0,
  abortController: null,
};

export class TelegramBotManager {
  public getStatus() {
    return {
      isActive: state.isActive,
      hasToken: Boolean(state.token),
      botUsername: state.botUsername,
    };
  }

  public async setToken(token: string) {
    state.token = token.trim();
    if (state.isActive) {
      await this.stopPolling();
      await this.startPolling(state.token);
    }
  }

  public async verifyToken(token: string): Promise<{ ok: boolean; username?: string; error?: string }> {
    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/getMe`);
      const data = await res.json();
      if (data.ok && data.result) {
        return { ok: true, username: data.result.username };
      }
      return { ok: false, error: data.description || 'Неверный токен' };
    } catch (err: any) {
      return { ok: false, error: err.message || 'Ошибка подключения к api.telegram.org' };
    }
  }

  public async startPolling(token?: string): Promise<{ success: boolean; username?: string; message?: string }> {
    const activeToken = token || state.token;
    if (!activeToken) {
      return { success: false, message: 'TELEGRAM_BOT_TOKEN не указан' };
    }

    if (state.isActive) {
      return { success: true, username: state.botUsername || undefined, message: 'Бот уже запущен' };
    }

    const verification = await this.verifyToken(activeToken);
    if (!verification.ok) {
      return { success: false, message: verification.error };
    }

    state.token = activeToken;
    state.botUsername = verification.username || null;
    state.isActive = true;
    state.abortController = new AbortController();

    console.log(`🤖 Telegram бот @${state.botUsername} запущен в режиме Long Polling`);

    // Run polling loop in background
    this.runPollingLoop(state.abortController.signal);

    return { success: true, username: state.botUsername || undefined, message: 'Бот успешно запущен' };
  }

  public async stopPolling(): Promise<{ success: boolean }> {
    if (!state.isActive) return { success: true };

    state.isActive = false;
    if (state.abortController) {
      state.abortController.abort();
      state.abortController = null;
    }
    console.log('🛑 Telegram бот остановлен');
    return { success: true };
  }

  private async runPollingLoop(signal: AbortSignal) {
    while (state.isActive && !signal.aborted) {
      try {
        const url = `https://api.telegram.org/bot${state.token}/getUpdates?offset=${state.lastUpdateId + 1}&timeout=20`;
        const res = await fetch(url, { signal });
        const data = await res.json();

        if (data.ok && Array.isArray(data.result)) {
          for (const update of data.result) {
            state.lastUpdateId = Math.max(state.lastUpdateId, update.update_id);
            await this.handleUpdate(update).catch((err) => {
              console.error('Ошибка обработки апдейта Telegram:', err);
            });
          }
        } else if (!data.ok) {
          console.warn('Telegram getUpdates returned error:', data.description);
          await new Promise((r) => setTimeout(r, 3000));
        }
      } catch (err: any) {
        if (signal.aborted) break;
        console.error('Ошибка в цикле polling Telegram:', err.message);
        await new Promise((r) => setTimeout(r, 4000));
      }
    }
  }

  public async handleUpdate(update: any) {
    const message = update.message;
    if (!message || !message.text) return;

    const chatId = message.chat.id;
    const user = message.from;
    const text: string = message.text.trim();

    // 1. Save user and chat in DB
    if (user) {
      await dbService.upsertUser({
        id: user.id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        language_code: user.language_code,
      });
    }

    await dbService.upsertChat({
      id: chatId,
      type: message.chat.type,
      title: message.chat.title || (user ? `${user.first_name} ${user.last_name || ''}`.trim() : undefined),
    });

    // 2. Command /start
    if (text.startsWith('/start')) {
      const welcome =
        `👋 Привет, ${user?.first_name || 'друг'}!\n\n` +
        `Я AI-ассистент на базе модели **Gemini 3.1 Flash Lite** с сохранением истории диалога в **PostgreSQL**.\n\n` +
        `✨ **Возможности:**\n` +
        `• 💬 Общение с учетом контекста разговора\n` +
        `• 🎨 Генерация изображений: \`/image <описание>\`\n` +
        `• 🧹 Очистка контекста: \`/clear\`\n` +
        `• 📊 Статистика сообщений: \`/stats\`\n` +
        `• ℹ️ Справка: \`/help\`\n\n` +
        `Напиши мне любой вопрос или задачу!`;

      await this.sendTelegramMessage(chatId, welcome);
      return;
    }

    // 3. Command /help
    if (text.startsWith('/help')) {
      const help =
        `📖 *Команды бота:*\n\n` +
        `• \`/image <промпт>\` — Генерация изображения по тексту\n` +
        `• \`/clear\` — Сброс памяти текущего диалога\n` +
        `• \`/stats\` — Показать статистику сохраненных сообщений\n` +
        `• \`/model\` — Информация о модели Gemini Flash Lite\n\n` +
        `Все остальные сообщения обрабатываются нейросетью с учетом контекста переписки.`;
      await this.sendTelegramMessage(chatId, help);
      return;
    }

    // 4. Command /model
    if (text.startsWith('/model')) {
      const modelInfo =
        `🧠 *Информация о модели:*\n\n` +
        `• Модель чата: \`gemini-3.1-flash-lite\`\n` +
        `• Модель генерации картинок: \`gemini-3.1-flash-lite-image\`\n` +
        `• База данных: PostgreSQL 16\n` +
        `• Контекстное окно: до 15 последних сообщений`;
      await this.sendTelegramMessage(chatId, modelInfo);
      return;
    }

    // 5. Command /clear
    if (text.startsWith('/clear')) {
      await dbService.clearChatHistory(chatId);
      await this.sendTelegramMessage(chatId, '🧹 Контекст беседы очищен! Начнем сначала.');
      return;
    }

    // 6. Command /stats
    if (text.startsWith('/stats')) {
      const msgs = await dbService.getMessages(chatId);
      await this.sendTelegramMessage(
        chatId,
        `📊 *Статистика чата:*\n\n` +
        `• Сообщений в базе: ${msgs.length}\n` +
        `• Тип чата: ${message.chat.type}\n` +
        `• ID чата: \`${chatId}\``
      );
      return;
    }

    // 7. Command /image or automatic "нарисуй" detection
    const isImageCommand = text.startsWith('/image') || /^(нарисуй|создай картинку|сгенерируй фото|draw):?\s*(.+)/i.test(text);

    if (isImageCommand) {
      let prompt = text.replace(/^\/image\s*/i, '').trim();
      const match = text.match(/^(нарисуй|создай картинку|сгенерируй фото|draw):?\s*(.+)/i);
      if (match && match[2]) {
        prompt = match[2].trim();
      }

      if (!prompt) {
        await this.sendTelegramMessage(chatId, '⚠️ Укажите описание картинки, например: `/image киберпанк кот в неоновых очках`');
        return;
      }

      // Save user prompt
      await dbService.saveMessage({
        chat_id: chatId,
        user_id: user?.id || 0,
        telegram_message_id: message.message_id,
        role: 'user',
        content: text,
      });

      await this.sendTelegramChatAction(chatId, 'upload_photo');
      const waitMsg = await this.sendTelegramMessage(chatId, '🎨 Генерирую изображение через Gemini 3.1 Flash Lite Image, пожалуйста, подождите...');

      try {
        const { base64Image, latencyMs } = await generateGeminiImage(prompt);

        // Save generated image to DB
        await dbService.saveGeneratedImage({
          chat_id: chatId,
          user_id: user?.id || 0,
          prompt,
          image_data: `data:image/png;base64,${base64Image}`,
        });

        // Send photo to Telegram
        await this.sendTelegramPhoto(chatId, base64Image, `🎨 «${prompt}»\n⏱ Время генерации: ${(latencyMs / 1000).toFixed(1)} сек.\n🤖 gemini-3.1-flash-lite-image`);

        if (waitMsg && waitMsg.result?.message_id) {
          await this.deleteTelegramMessage(chatId, waitMsg.result.message_id).catch(() => {});
        }
      } catch (err: any) {
        console.error('Error generating image in Telegram:', err);
        await this.sendTelegramMessage(chatId, `❌ Ошибка при создании изображения: ${err.message || 'Сбой API'}`);
      }
      return;
    }

    // 8. Normal text conversation with context
    // Save user message in DB
    await dbService.saveMessage({
      chat_id: chatId,
      user_id: user?.id || 0,
      telegram_message_id: message.message_id,
      role: 'user',
      content: text,
    });

    await this.sendTelegramChatAction(chatId, 'typing');

    try {
      // Load context from PostgreSQL
      const recentHistory = await dbService.getRecentMessages(chatId, 15);

      // Call Gemini 3.1 Flash Lite
      const { text: responseText, latencyMs, tokenCount } = await askGeminiFlashLite(
        recentHistory,
        text,
        { systemInstruction: DEFAULT_SYSTEM_INSTRUCTION }
      );

      // Send to Telegram
      const sent = await this.sendTelegramMessage(chatId, responseText);

      // Save AI response in DB
      await dbService.saveMessage({
        chat_id: chatId,
        user_id: user?.id || 0,
        telegram_message_id: sent?.result?.message_id,
        role: 'model',
        content: responseText,
        latency_ms: latencyMs,
        token_count: tokenCount,
      });
    } catch (err: any) {
      console.error('Error answering Telegram message:', err);
      await this.sendTelegramMessage(chatId, `⚠️ Ошибка: ${err.message || 'Не удалось получить ответ'}`);
    }
  }

  public async sendTelegramMessage(chatId: number, text: string) {
    if (!state.token) return null;
    try {
      // First try Markdown
      const res = await fetch(`https://api.telegram.org/bot${state.token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: text,
          parse_mode: 'Markdown',
        }),
      });
      const data = await res.json();
      if (!data.ok) {
        // Fallback to plain text if Markdown parsing fails
        const fallbackRes = await fetch(`https://api.telegram.org/bot${state.token}/sendMessage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            chat_id: chatId,
            text: text,
          }),
        });
        return await fallbackRes.json();
      }
      return data;
    } catch (err) {
      console.error('sendTelegramMessage error:', err);
      return null;
    }
  }

  public async sendTelegramChatAction(chatId: number, action: string) {
    if (!state.token) return;
    try {
      await fetch(`https://api.telegram.org/bot${state.token}/sendChatAction`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, action }),
      });
    } catch {}
  }

  public async deleteTelegramMessage(chatId: number, messageId: number) {
    if (!state.token) return;
    try {
      await fetch(`https://api.telegram.org/bot${state.token}/deleteMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, message_id: messageId }),
      });
    } catch {}
  }

  public async sendTelegramPhoto(chatId: number, base64Data: string, caption?: string) {
    if (!state.token) return;
    try {
      const buffer = Buffer.from(base64Data, 'base64');
      const blob = new Blob([buffer], { type: 'image/png' });

      const formData = new FormData();
      formData.append('chat_id', String(chatId));
      formData.append('photo', blob, 'image.png');
      if (caption) {
        formData.append('caption', caption);
      }

      const res = await fetch(`https://api.telegram.org/bot${state.token}/sendPhoto`, {
        method: 'POST',
        body: formData,
      });
      return await res.json();
    } catch (err) {
      console.error('sendTelegramPhoto error:', err);
    }
  }
}

export const telegramManager = new TelegramBotManager();
