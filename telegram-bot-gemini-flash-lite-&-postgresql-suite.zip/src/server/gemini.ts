import { GoogleGenAI } from '@google/genai';
import * as dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;

export const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export const DEFAULT_SYSTEM_INSTRUCTION = `Ты — полезный, дружелюбный и быстрый Telegram-бот ассистент.
Твоя модель: Gemini 3.1 Flash Lite от Google.
Особенности:
- Отвечай понятно, лаконично и структурированно.
- Активно используй стандартное форматирование Telegram (Markdown: жирный текст **текст**, курсив *текст*, списки, моноширинный код \`код\` и блоки кода с указанием языка).
- Ты хранишь историю и помнишь контекст сообщений в базе данных PostgreSQL.
- Если пользователь просит нарисовать или сгенерировать картинку, упомяни команду /image <описание>.
- Отвечай на том языке, на котором пишет пользователь (по умолчанию на русском).`;

export interface ChatHistoryItem {
  role: 'user' | 'model' | 'system';
  content: string;
}

export async function askGeminiFlashLite(
  history: ChatHistoryItem[],
  newMessage: string,
  options?: {
    systemInstruction?: string;
    temperature?: number;
  }
): Promise<{ text: string; tokenCount?: number; latencyMs: number }> {
  const startTime = Date.now();

  // Filter and format contents for Google GenAI SDK
  const formattedContents = [
    ...history
      .filter((m) => m.content && m.content.trim().length > 0)
      .map((m) => ({
        role: m.role === 'model' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
    {
      role: 'user',
      parts: [{ text: newMessage }],
    },
  ];

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: formattedContents,
      config: {
        systemInstruction: options?.systemInstruction || DEFAULT_SYSTEM_INSTRUCTION,
        temperature: options?.temperature ?? 0.7,
      },
    });

    const latencyMs = Date.now() - startTime;
    const text = response.text || 'Не удалось сформировать ответ.';
    const tokenCount = response.usageMetadata?.totalTokenCount;

    return {
      text,
      tokenCount,
      latencyMs,
    };
  } catch (error: any) {
    console.error('Gemini 3.1 Flash Lite generation error:', error);
    // If the error was due to an empty or strict key, provide a clear diagnostic
    throw new Error(error.message || 'Ошибка генерации в Google Gemini API');
  }
}

export async function generateGeminiImage(prompt: string): Promise<{ base64Image: string; latencyMs: number }> {
  const startTime = Date.now();

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [
          {
            text: `High quality, detailed artistic image: ${prompt}`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: '1:1',
        },
      },
    });

    const latencyMs = Date.now() - startTime;
    const candidates = response.candidates;
    if (!candidates || candidates.length === 0) {
      throw new Error('Кандидаты для генерации изображения не возвращены');
    }

    const parts = candidates[0].content?.parts || [];
    for (const part of parts) {
      if (part.inlineData && part.inlineData.data) {
        return {
          base64Image: part.inlineData.data,
          latencyMs,
        };
      }
    }

    throw new Error('Изображение не найдено в ответе модели');
  } catch (error: any) {
    console.error('Gemini Image generation error:', error);
    throw new Error(error.message || 'Ошибка генерации изображения');
  }
}
