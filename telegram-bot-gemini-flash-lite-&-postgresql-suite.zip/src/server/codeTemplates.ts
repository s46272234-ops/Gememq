export interface CodeFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export const CODE_TEMPLATES: Record<string, CodeFile> = {
  'bot.ts': {
    name: 'bot.ts',
    path: 'src/bot.ts',
    language: 'typescript',
    description: 'Основной код Telegram-бота: обработчик команд (/start, /image, /clear, /stats), сообщений и диалогового контекста.',
    content: `/**
 * Telegram AI Bot powered by Gemini 3.1 Flash Lite & PostgreSQL
 *
 * Requirements:
 * npm install @google/genai pg dotenv grammy
 */
import { Bot, InputFile } from 'grammy';
import * as dotenv from 'dotenv';
import { db } from './database.js';
import { generateGeminiResponse, generateGeminiImage } from './gemini.js';

dotenv.config();

const token = process.env.TELEGRAM_BOT_TOKEN;
if (!token) {
  console.error('Ошибка: TELEGRAM_BOT_TOKEN не указан в .env');
  process.exit(1);
}

const bot = new Bot(token);

// Команда /start
bot.command('start', async (ctx) => {
  const user = ctx.from;
  const chat = ctx.chat;

  if (user && chat) {
    await db.upsertUser({
      id: user.id,
      username: user.username,
      first_name: user.first_name,
      last_name: user.last_name,
      language_code: user.language_code,
    });
    await db.upsertChat({
      id: chat.id,
      type: chat.type,
      title: 'title' in chat ? chat.title : undefined,
    });
  }

  const welcomeText = 
    '👋 Привет! Я AI-ассистент на базе модели **Gemini 3.1 Flash Lite** с памятью диалога в **PostgreSQL**.\\n\\n' +
    '✨ **Что я умею:**\\n' +
    '• 💬 Отвечать на любые вопросы и помнить контекст разговора\\n' +
    '• 🎨 Генерировать картинки: отправь команду /image <описание>\\n' +
    '• 🧹 Сбросить контекст: /clear\\n' +
    '• 📊 Статистика переписки: /stats\\n' +
    '• ℹ️ Справка: /help\\n\\n' +
    'Просто напиши мне любой вопрос!';

  await ctx.reply(welcomeText, { parse_mode: 'Markdown' });
});

// Команда /help
bot.command('help', async (ctx) => {
  await ctx.reply(
    '📖 *Справка по командам:*\\n\\n' +
    '/image <текст> — Сгенерировать картинку по описанию\\n' +
    '/clear — Очистить историю сообщений текущего диалога\\n' +
    '/stats — Показать статистику сохраненных сообщений\\n' +
    '/model — Показать информацию об используемой AI модели\\n\\n' +
    'Все текстовые сообщения обрабатываются с учетом предыдущих реплик!',
    { parse_mode: 'Markdown' }
  );
});

// Команда /model
bot.command('model', async (ctx) => {
  await ctx.reply(
    '🧠 *Используемые модели Google Gemini:*\\n\\n' +
    '• **Текстовая модель:** \`gemini-3.1-flash-lite\` (высокая скорость, минимальная задержка, поддержка диалогового контекста)\\n' +
    '• **Генерация изображений:** \`gemini-3.1-flash-lite-image\`\\n' +
    '• **База данных:** PostgreSQL 16 (хранение пользователей, чатов, сообщений и сгенерированных артов)',
    { parse_mode: 'Markdown' }
  );
});

// Команда /clear — очистить контекст
bot.command('clear', async (ctx) => {
  const chatId = ctx.chat.id;
  await db.clearChatHistory(chatId);
  await ctx.reply('🧹 Контекст беседы успешно очищен! Начнем с чистого листа.');
});

// Команда /stats — статистика
bot.command('stats', async (ctx) => {
  const chatId = ctx.chat.id;
  const stats = await db.getChatStats(chatId);
  await ctx.reply(
    \`📊 *Статистика чата:*\\n\\n\` +
    \`• Всего сообщений в базе: \${stats.totalMessages}\\n\` +
    \`• Сгенерировано картинок: \${stats.totalImages}\\n\` +
    \`• Дата первого сообщения: \${stats.firstMessageDate || 'сегодня'}\`,
    { parse_mode: 'Markdown' }
  );
});

// Команда /image — генерация картинок
bot.command('image', async (ctx) => {
  const prompt = ctx.match?.trim();
  if (!prompt) {
    await ctx.reply('⚠️ Пожалуйста, укажите описание изображения.\\nПример: \`/image футуристический неоновый город под дождем\`', {
      parse_mode: 'Markdown',
    });
    return;
  }

  const waitMsg = await ctx.reply('🎨 Генерирую изображение по вашему запросу, пожалуйста, подождите...');
  const startTime = Date.now();

  try {
    const base64Data = await generateGeminiImage(prompt);
    const buffer = Buffer.from(base64Data, 'base64');
    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);

    // Сохраняем в PostgreSQL
    await db.saveGeneratedImage({
      chat_id: ctx.chat.id,
      user_id: ctx.from?.id || 0,
      prompt,
      image_data: base64Data,
      aspect_ratio: '1:1',
    });

    await ctx.replyWithPhoto(new InputFile(buffer, 'image.png'), {
      caption: \`🎨 «\${prompt}»\\n⏱ Время генерации: \${elapsed} сек.\\n🤖 Модель: gemini-3.1-flash-lite-image\`,
    });

    // Удаляем сообщение ожидания
    await ctx.api.deleteMessage(ctx.chat.id, waitMsg.message_id).catch(() => {});
  } catch (error: any) {
    console.error('Ошибка генерации изображения:', error);
    await ctx.api.editMessageText(
      ctx.chat.id,
      waitMsg.message_id,
      \`❌ Не удалось сгенерировать изображение: \${error.message || 'Ошибка API'}\`
    );
  }
});

// Обработка обычных текстовых сообщений (с диалоговым контекстом)
bot.on('message:text', async (ctx) => {
  const text = ctx.message.text;
  const chatId = ctx.chat.id;
  const user = ctx.from;

  // Автоматическое распознавание запроса на рисование ("нарисуй", "сгенерируй картинку")
  const drawRegex = /^(нарисуй|создай картинку|сгенерируй фото|нарисуй мне|draw|generate image):?\\s*(.+)/i;
  const drawMatch = text.match(drawRegex);
  if (drawMatch && drawMatch[2]) {
    // Перенаправляем на команду /image
    ctx.match = drawMatch[2];
    return (bot as any).handleUpdate({
      ...ctx.update,
      message: {
        ...ctx.message,
        text: \`/image \${drawMatch[2]}\`,
      },
    });
  }

  // Обновляем информацию о пользователе и чате
  if (user) {
    await db.upsertUser({
      id: user.id,
      username: user.username,
      first_name: user.first_name,
      last_name: user.last_name,
      language_code: user.language_code,
    });
  }
  await db.upsertChat({
    id: chatId,
    type: ctx.chat.type,
    title: 'title' in ctx.chat ? ctx.chat.title : undefined,
  });

  // Сохраняем сообщение пользователя в PostgreSQL
  await db.saveMessage({
    chat_id: chatId,
    user_id: user.id,
    telegram_message_id: ctx.message.message_id,
    role: 'user',
    content: text,
  });

  // Отправляем индикатор набора текста
  await ctx.replyWithChatAction('typing');

  const startTime = Date.now();
  try {
    // Загружаем предыдущие N сообщений из базы данных PostgreSQL
    const contextMessages = await db.getRecentMessages(chatId, 15);

    // Генерируем ответ модели Gemini 3.1 Flash Lite
    const responseText = await generateGeminiResponse(contextMessages, text);
    const latencyMs = Date.now() - startTime;

    // Сохраняем ответ ассистента в PostgreSQL
    const sentMsg = await ctx.reply(responseText, { parse_mode: 'Markdown' }).catch(async () => {
      // Фолбэк на обычный текст при ошибках синтаксиса Markdown в ответе
      return await ctx.reply(responseText);
    });

    await db.saveMessage({
      chat_id: chatId,
      user_id: user.id,
      telegram_message_id: sentMsg.message_id,
      role: 'model',
      content: responseText,
      latency_ms: latencyMs,
    });
  } catch (error: any) {
    console.error('Ошибка обработки сообщения:', error);
    await ctx.reply(\`⚠️ Произошла ошибка при обращении к AI: \${error.message || 'Попробуйте позже'}\`);
  }
});

// Запуск бота
async function main() {
  console.log('Инициализация базы данных PostgreSQL...');
  await db.init();

  console.log('Запуск Telegram-бота на базе Gemini 3.1 Flash Lite...');
  await bot.start({
    onStart: (botInfo) => {
      console.log(\`✅ Бот @\${botInfo.username} успешно запущен и слушает сообщения!\`);
    },
  });
}

main().catch(console.error);
`,
  },

  'gemini.ts': {
    name: 'gemini.ts',
    path: 'src/gemini.ts',
    language: 'typescript',
    description: 'Интеграция с официальным SDK @google/genai: модель gemini-3.1-flash-lite для чата и gemini-3.1-flash-lite-image для картинок.',
    content: `/**
 * Модуль интеграции с Google Gemini API
 * Использует официальный SDK @google/genai
 */
import { GoogleGenAI } from '@google/genai';
import * as dotenv from 'dotenv';

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  throw new Error('GEMINI_API_KEY не задан в переменных окружения');
}

export const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export const SYSTEM_INSTRUCTION = \`Ты — умный, дружелюбный и эрудированный Telegram-ассистент.
Твоя языковая модель: Gemini 3.1 Flash Lite от Google.
Правила форматирования:
- Отвечай красиво, четко и структурировано.
- Используй стандартное Markdown-форматирование Telegram (жирный текст **текст**, курсив *текст*, моноширинный код \\\`код\\\`, блоки кода с указанием языка).
- Если тебя просят сгенерировать картинку, напомни, что в боте есть команда /image <описание>, либо предложи подробный промпт.
- Ты помнишь предыдущую нить беседы благодаря истории сообщений из базы данных PostgreSQL.
- Отвечай на том языке, на котором обращается пользователь (по умолчанию русский).\`;

export interface HistoryMessage {
  role: 'user' | 'model' | 'system';
  content: string;
}

/**
 * Генерация ответа в диалоге с контекстом с помощью gemini-3.1-flash-lite
 */
export async function generateGeminiResponse(
  history: HistoryMessage[],
  newMessage: string
): Promise<string> {
  // Формируем массив contents в формате Google GenAI SDK
  const formattedContents = [
    ...history.map((msg) => ({
      role: msg.role === 'model' ? 'model' : 'user',
      parts: [{ text: msg.content }],
    })),
    {
      role: 'user',
      parts: [{ text: newMessage }],
    },
  ];

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: formattedContents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
      topP: 0.95,
    },
  });

  const responseText = response.text;
  if (!responseText) {
    throw new Error('Модель вернула пустой ответ');
  }

  return responseText;
}

/**
 * Генерация изображения с помощью gemini-3.1-flash-lite-image
 * Возвращает base64-строку изображения
 */
export async function generateGeminiImage(prompt: string): Promise<string> {
  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite-image',
    contents: {
      parts: [
        {
          text: \`High quality, detailed, realistic or artistic rendition: \${prompt}\`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: '1:1',
      },
    },
  });

  const candidates = response.candidates;
  if (!candidates || candidates.length === 0) {
    throw new Error('Кандидаты генерации отсутствуют');
  }

  const parts = candidates[0].content?.parts || [];
  for (const part of parts) {
    if (part.inlineData && part.inlineData.data) {
      return part.inlineData.data;
    }
  }

  throw new Error('Модель не вернула данные изображения');
}
`,
  },

  'database.ts': {
    name: 'database.ts',
    path: 'src/database.ts',
    language: 'typescript',
    description: 'Работа с PostgreSQL через pg.Pool: сохранение юзеров, чатов, сообщений, загрузка контекста диалога.',
    content: `/**
 * Модуль взаимодействия с базой данных PostgreSQL
 * Использует pg.Pool с пулом соединений
 */
import pg from 'pg';
import * as dotenv from 'dotenv';
import { HistoryMessage } from './gemini.js';

dotenv.config();

const { Pool } = pg;

export interface DBUser {
  id: number;
  username?: string;
  first_name: string;
  last_name?: string;
  language_code?: string;
}

export interface DBChat {
  id: number;
  type: string;
  title?: string;
}

export interface DBSaveMessage {
  chat_id: number;
  user_id: number;
  telegram_message_id: number;
  role: 'user' | 'model' | 'system';
  content: string;
  token_count?: number;
  latency_ms?: number;
}

export interface DBSaveImage {
  chat_id: number;
  user_id: number;
  prompt: string;
  image_data: string;
  aspect_ratio?: string;
}

class Database {
  private pool: pg.Pool;

  constructor() {
    // Подключение к PostgreSQL через объектную конфигурацию или DATABASE_URL
    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      host: process.env.PGHOST || process.env.SQL_HOST || 'localhost',
      port: Number(process.env.PGPORT || 5432),
      user: process.env.PGUSER || process.env.SQL_USER || 'postgres',
      password: process.env.PGPASSWORD || process.env.SQL_PASSWORD || 'postgres',
      database: process.env.PGDATABASE || process.env.SQL_DB_NAME || 'telegram_bot_db',
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    });

    this.pool.on('error', (err) => {
      console.error('Неожиданная ошибка на клиенте пула PostgreSQL:', err);
    });
  }

  /**
   * Инициализация таблиц схемы базы данных
   */
  async init(): Promise<void> {
    const client = await this.pool.connect();
    try {
      await client.query(\`
        CREATE TABLE IF NOT EXISTS tg_users (
          id BIGINT PRIMARY KEY,
          username TEXT,
          first_name TEXT NOT NULL,
          last_name TEXT,
          language_code TEXT,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          last_active_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS tg_chats (
          id BIGINT PRIMARY KEY,
          type TEXT NOT NULL,
          title TEXT,
          system_prompt TEXT,
          context_limit INT DEFAULT 15,
          created_at TIMESTAMPTZ DEFAULT NOW(),
          updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS tg_messages (
          id BIGSERIAL PRIMARY KEY,
          chat_id BIGINT NOT NULL REFERENCES tg_chats(id) ON DELETE CASCADE,
          user_id BIGINT REFERENCES tg_users(id) ON DELETE SET NULL,
          telegram_message_id BIGINT,
          role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'model', 'system')),
          content TEXT NOT NULL,
          token_count INT,
          latency_ms INT,
          created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS image_generations (
          id BIGSERIAL PRIMARY KEY,
          chat_id BIGINT NOT NULL REFERENCES tg_chats(id) ON DELETE CASCADE,
          user_id BIGINT REFERENCES tg_users(id) ON DELETE SET NULL,
          prompt TEXT NOT NULL,
          image_data TEXT NOT NULL,
          aspect_ratio VARCHAR(20) DEFAULT '1:1',
          created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE INDEX IF NOT EXISTS idx_messages_chat_id_created 
        ON tg_messages (chat_id, created_at DESC);

        CREATE INDEX IF NOT EXISTS idx_images_chat_id 
        ON image_generations (chat_id, created_at DESC);
      \`);
      console.log('✅ Таблицы PostgreSQL успешно проверены/созданы');
    } finally {
      client.release();
    }
  }

  /**
   * Сохранить или обновить пользователя
   */
  async upsertUser(user: DBUser): Promise<void> {
    const query = \`
      INSERT INTO tg_users (id, username, first_name, last_name, language_code, last_active_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
      ON CONFLICT (id) DO UPDATE SET
        username = EXCLUDED.username,
        first_name = EXCLUDED.first_name,
        last_name = EXCLUDED.last_name,
        language_code = EXCLUDED.language_code,
        last_active_at = NOW();
    \`;
    await this.pool.query(query, [
      user.id,
      user.username || null,
      user.first_name,
      user.last_name || null,
      user.language_code || null,
    ]);
  }

  /**
   * Сохранить или обновить чат
   */
  async upsertChat(chat: DBChat): Promise<void> {
    const query = \`
      INSERT INTO tg_chats (id, type, title, updated_at)
      VALUES ($1, $2, $3, NOW())
      ON CONFLICT (id) DO UPDATE SET
        type = EXCLUDED.type,
        title = COALESCE(EXCLUDED.title, tg_chats.title),
        updated_at = NOW();
    \`;
    await this.pool.query(query, [chat.id, chat.type, chat.title || null]);
  }

  /**
   * Сохранить сообщение диалога
   */
  async saveMessage(msg: DBSaveMessage): Promise<void> {
    const query = \`
      INSERT INTO tg_messages (chat_id, user_id, telegram_message_id, role, content, token_count, latency_ms)
      VALUES ($1, $2, $3, $4, $5, $6, $7);
    \`;
    await this.pool.query(query, [
      msg.chat_id,
      msg.user_id,
      msg.telegram_message_id,
      msg.role,
      msg.content,
      msg.token_count || null,
      msg.latency_ms || null,
    ]);
  }

  /**
   * Получить последние N сообщений для контекста Gemini (в хронологическом порядке)
   */
  async getRecentMessages(chatId: number, limit = 15): Promise<HistoryMessage[]> {
    const query = \`
      SELECT role, content
      FROM (
        SELECT role, content, created_at
        FROM tg_messages
        WHERE chat_id = $1
        ORDER BY created_at DESC
        LIMIT $2
      ) sub
      ORDER BY created_at ASC;
    \`;
    const res = await this.pool.query(query, [chatId, limit]);
    return res.rows.map((row) => ({
      role: row.role as 'user' | 'model' | 'system',
      content: row.content,
    }));
  }

  /**
   * Очистить историю сообщений для указанного чата (/clear)
   */
  async clearChatHistory(chatId: number): Promise<void> {
    await this.pool.query('DELETE FROM tg_messages WHERE chat_id = $1;', [chatId]);
  }

  /**
   * Сохранить запись о сгенерированном изображении
   */
  async saveGeneratedImage(img: DBSaveImage): Promise<void> {
    const query = \`
      INSERT INTO image_generations (chat_id, user_id, prompt, image_data, aspect_ratio)
      VALUES ($1, $2, $3, $4, $5);
    \`;
    await this.pool.query(query, [
      img.chat_id,
      img.user_id,
      img.prompt,
      img.image_data,
      img.aspect_ratio || '1:1',
    ]);
  }

  /**
   * Статистика по чату
   */
  async getChatStats(chatId: number) {
    const msgRes = await this.pool.query(
      'SELECT COUNT(*) as count, MIN(created_at) as first_date FROM tg_messages WHERE chat_id = $1;',
      [chatId]
    );
    const imgRes = await this.pool.query(
      'SELECT COUNT(*) as count FROM image_generations WHERE chat_id = $1;',
      [chatId]
    );

    return {
      totalMessages: Number(msgRes.rows[0]?.count || 0),
      firstMessageDate: msgRes.rows[0]?.first_date
        ? new Date(msgRes.rows[0].first_date).toLocaleDateString('ru-RU')
        : null,
      totalImages: Number(imgRes.rows[0]?.count || 0),
    };
  }
}

export const db = new Database();
`,
  },

  'schema.sql': {
    name: 'schema.sql',
    path: 'schema.sql',
    language: 'sql',
    description: 'Полный SQL DDL-скрипт PostgreSQL: таблицы пользователей, чатов, сообщений, сгенерированных изображений, индексы и триггеры.',
    content: `-- =======================================================
-- Схема PostgreSQL для Telegram AI Бота на Gemini 3.1 Flash Lite
-- =======================================================

-- 1. Таблица пользователей Telegram
CREATE TABLE IF NOT EXISTS tg_users (
  id BIGINT PRIMARY KEY,                        -- Telegram User ID
  username TEXT,                                -- @username (если есть)
  first_name TEXT NOT NULL,                     -- Имя пользователя
  last_name TEXT,                               -- Фамилия пользователя
  language_code VARCHAR(10) DEFAULT 'ru',       -- Языковой код (ru, en и др.)
  created_at TIMESTAMPTZ DEFAULT NOW(),         -- Дата первого обращения
  last_active_at TIMESTAMPTZ DEFAULT NOW()      -- Дата последней активности
);

-- 2. Таблица чатов (личные диалоги, группы, супергруппы)
CREATE TABLE IF NOT EXISTS tg_chats (
  id BIGINT PRIMARY KEY,                        -- Telegram Chat ID
  type VARCHAR(30) NOT NULL,                    -- 'private', 'group', 'supergroup', 'channel'
  title TEXT,                                   -- Название группы или имя собеседника
  system_prompt TEXT,                           -- Кастомный системный промпт (опционально)
  context_limit INT DEFAULT 15,                 -- Количество реплик для передачи в контекст Gemini
  created_at TIMESTAMPTZ DEFAULT NOW(),         -- Дата создания
  updated_at TIMESTAMPTZ DEFAULT NOW()          -- Дата обновления
);

-- 3. Таблица истории сообщений диалогов (контекст для LLM)
CREATE TABLE IF NOT EXISTS tg_messages (
  id BIGSERIAL PRIMARY KEY,
  chat_id BIGINT NOT NULL REFERENCES tg_chats(id) ON DELETE CASCADE,
  user_id BIGINT REFERENCES tg_users(id) ON DELETE SET NULL,
  telegram_message_id BIGINT,                   -- Идентификатор сообщения в Telegram
  role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'model', 'system')),
  content TEXT NOT NULL,                        -- Текст сообщения
  token_count INT,                              -- Количество токенов (опционально)
  latency_ms INT,                               -- Время генерации в миллисекундах
  created_at TIMESTAMPTZ DEFAULT NOW()          -- Временная метка
);

-- 4. Таблица сгенерированных изображений (gemini-3.1-flash-lite-image)
CREATE TABLE IF NOT EXISTS image_generations (
  id BIGSERIAL PRIMARY KEY,
  chat_id BIGINT NOT NULL REFERENCES tg_chats(id) ON DELETE CASCADE,
  user_id BIGINT REFERENCES tg_users(id) ON DELETE SET NULL,
  prompt TEXT NOT NULL,                         -- Текстовое описание запроса
  image_data TEXT NOT NULL,                     -- Base64 код или ссылка на хранилище S3
  aspect_ratio VARCHAR(20) DEFAULT '1:1',       -- Пропорции (1:1, 16:9, 9:16)
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =======================================================
-- Индексы для оптимизации выборки контекста
-- =======================================================

-- Быстрая выборка последних N сообщений для конкретного чата:
CREATE INDEX IF NOT EXISTS idx_messages_chat_id_created 
ON tg_messages (chat_id, created_at DESC);

-- Индекс по пользователю для аналитики:
CREATE INDEX IF NOT EXISTS idx_messages_user_id 
ON tg_messages (user_id);

-- Индекс для картинок:
CREATE INDEX IF NOT EXISTS idx_images_chat_id 
ON image_generations (chat_id, created_at DESC);

-- =======================================================
-- Полезные запросы для работы с контекстом
-- =======================================================

-- Запрос: получить последние 15 сообщений для контекста Gemini:
-- SELECT role, content FROM (
--   SELECT role, content, created_at 
--   FROM tg_messages 
--   WHERE chat_id = :chat_id 
--   ORDER BY created_at DESC 
--   LIMIT 15
-- ) sub 
-- ORDER BY created_at ASC;
`,
  },

  'docker-compose.yml': {
    name: 'docker-compose.yml',
    path: 'docker-compose.yml',
    language: 'yaml',
    description: 'Docker Compose файл для мгновенного развертывания бота вместе с базой данных PostgreSQL 16 и веб-панелью pgAdmin.',
    content: `version: '3.8'

services:
  # База данных PostgreSQL 16
  postgres:
    image: postgres:16-alpine
    container_name: telegram_bot_postgres
    restart: always
    environment:
      POSTGRES_USER: bot_user
      POSTGRES_PASSWORD: bot_secure_password_123
      POSTGRES_DB: telegram_bot_db
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./schema.sql:/docker-entrypoint-initdb.d/schema.sql:ro
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U bot_user -d telegram_bot_db"]
      interval: 5s
      timeout: 5s
      retries: 5

  # Сервис Telegram-бота
  telegram-bot:
    build: .
    container_name: telegram_gemini_bot
    restart: always
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      TELEGRAM_BOT_TOKEN: \${TELEGRAM_BOT_TOKEN}
      GEMINI_API_KEY: \${GEMINI_API_KEY}
      DATABASE_URL: postgres://bot_user:bot_secure_password_123@postgres:5432/telegram_bot_db
      PGHOST: postgres
      PGPORT: 5432
      PGUSER: bot_user
      PGPASSWORD: bot_secure_password_123
      PGDATABASE: telegram_bot_db

  # Веб-интерфейс для просмотра базы данных (опционально)
  pgadmin:
    image: dpage/pgadmin4
    container_name: telegram_bot_pgadmin
    restart: unless-stopped
    environment:
      PGADMIN_DEFAULT_EMAIL: admin@example.com
      PGADMIN_DEFAULT_PASSWORD: admin
    ports:
      - "5050:80"
    depends_on:
      - postgres

volumes:
  postgres_data:
`,
  },

  'Dockerfile': {
    name: 'Dockerfile',
    path: 'Dockerfile',
    language: 'dockerfile',
    description: 'Легковесный многоэтапный Dockerfile для сборки TypeScript кода и запуска Node.js 22 приложения.',
    content: `FROM node:22-alpine AS builder

WORKDIR /app

COPY package*.json tsconfig.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM node:22-alpine AS runner

WORKDIR /app
ENV NODE_ENV=production

COPY package*.json ./
RUN npm ci --omit=dev

COPY --from=builder /app/dist ./dist

CMD ["node", "dist/bot.js"]
`,
  },

  '.env.example': {
    name: '.env.example',
    path: '.env.example',
    language: 'bash',
    description: 'Пример конфигурационного файла со всеми необходимыми ключами и параметрами подключения.',
    content: `# Токен вашего Telegram-бота, полученный у @BotFather
TELEGRAM_BOT_TOKEN="123456789:ABCdefGhIJKlmNoPQRsTUVwxyZ"

# API-ключ Google Gemini API (Google AI Studio)
GEMINI_API_KEY="AIzaSyYourSecretGeminiApiKeyHere"

# Настройки подключения к базе данных PostgreSQL
DATABASE_URL="postgres://bot_user:bot_secure_password_123@localhost:5432/telegram_bot_db"
PGHOST="localhost"
PGPORT="5432"
PGUSER="bot_user"
PGPASSWORD="bot_secure_password_123"
PGDATABASE="telegram_bot_db"

# Настройки модели Gemini
GEMINI_MODEL="gemini-3.1-flash-lite"
GEMINI_IMAGE_MODEL="gemini-3.1-flash-lite-image"
CONTEXT_LIMIT="15"
`,
  },

  'package.json': {
    name: 'package.json (for bot)',
    path: 'package.json',
    language: 'json',
    description: 'Файл зависимостей для автономного проекта Telegram-бота.',
    content: `{
  "name": "telegram-gemini-flash-lite-bot",
  "version": "1.0.0",
  "description": "Telegram bot powered by Gemini 3.1 Flash Lite and PostgreSQL",
  "main": "dist/bot.js",
  "type": "module",
  "scripts": {
    "build": "tsc",
    "start": "node dist/bot.js",
    "dev": "tsx watch src/bot.ts"
  },
  "dependencies": {
    "@google/genai": "^2.4.0",
    "dotenv": "^17.2.3",
    "grammy": "^1.35.0",
    "pg": "^8.13.3"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "@types/pg": "^8.11.11",
    "tsx": "^4.19.3",
    "typescript": "^5.7.3"
  }
}
`,
  },

  'README.md': {
    name: 'README.md',
    path: 'README.md',
    language: 'markdown',
    description: 'Подробная пошаговая инструкция на русском языке: от создания бота в @BotFather до запуска на сервере.',
    content: `# 🤖 Telegram AI Бот на Gemini 3.1 Flash Lite с PostgreSQL

Полнофункциональный бот для Telegram с памятью диалога в базе данных PostgreSQL и генерацией картинок с помощью моделей Google Gemini.

---

## 🚀 Возможности
- ⚡ **Gemini 3.1 Flash Lite** — быстрая модель с минимальной задержкой ответа.
- 💬 **Сохранение контекста** — все сообщения сохраняются в PostgreSQL, история подтягивается автоматически при каждом новом вопросе.
- 🎨 **Генерация изображений** — команда \`/image <промпт>\` на модели \`gemini-3.1-flash-lite-image\`.
- 🧹 **Команда \`/clear\`** — мгновенное очищение контекста диалога в базе.
- 📊 **Команда \`/stats\`** — статистика по сообщениям и сгенерированным картинкам.
- 🐳 **Docker & Docker Compose** — запуск одной командой вместе с PostgreSQL 16.

---

## 📋 Требования
1. **Node.js** (версия 20 или выше) или **Docker**.
2. **Токен Telegram-бота**: создайте бота в Telegram через [@BotFather](https://t.me/BotFather) (команда \`/newbot\`).
3. **Google Gemini API Key**: получите ключ в [Google AI Studio](https://aistudio.google.com/app/apikey).
4. **PostgreSQL** (локально, в Docker, либо облачный: Supabase, Neon, Railway).

---

## 🛠 Быстрый запуск через Docker Compose (Рекомендуется)

1. Клонируйте проект или скопируйте файлы в папку.
2. Создайте файл \`.env\` на основе \`.env.example\`:
   \`\`\`bash
   cp .env.example .env
   \`\`\`
3. Внесите ваши ключи в \`.env\`:
   \`\`\`env
   TELEGRAM_BOT_TOKEN="ВАШ_ТОКЕН_ОТ_BOTFATHER"
   GEMINI_API_KEY="ВАШ_КЛЮЧ_GEMINI"
   \`\`\`
4. Запустите стек:
   \`\`\`bash
   docker compose up -d --build
   \`\`\`
5. Бот запустится, автоматически создаст таблицы в PostgreSQL и начнет отвечать пользователям в Telegram!

---

## 💻 Локальный запуск без Docker

1. Установите зависимости:
   \`\`\`bash
   npm install
   \`\`\`
2. Создайте базу данных в PostgreSQL и примените файл \`schema.sql\`:
   \`\`\`bash
   psql -U postgres -d telegram_bot_db -f schema.sql
   \`\`\`
3. Заполните \`.env\` файл.
4. Запустите в режиме разработки:
   \`\`\`bash
   npm run dev
   \`\`\`

---

## 📜 Структура проекта
- \`src/bot.ts\` — главный файл бота (обработка команд, сообщений, webhook/polling).
- \`src/gemini.ts\` — модуль генерации текста и картинок через \`@google/genai\`.
- \`src/database.ts\` — подключение к PostgreSQL через пул и SQL-запросы.
- \`schema.sql\` — DDL скрипт создания таблиц и индексов.
- \`docker-compose.yml\` — связка бота и PostgreSQL.
`,
  },
};
