import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';
import { dbService } from './src/server/db.ts';
import { askGeminiFlashLite, generateGeminiImage, DEFAULT_SYSTEM_INSTRUCTION } from './src/server/gemini.ts';
import { telegramManager } from './src/server/telegram.ts';
import { CODE_TEMPLATES } from './src/server/codeTemplates.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

// 1. Health check & status
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    isPostgres: dbService.isUsingRealPostgres(),
    model: 'gemini-3.1-flash-lite',
    time: new Date().toISOString(),
  });
});

// 2. Chat with Gemini Flash Lite (Simulator / Web API)
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      chat_id = 874192451,
      user_id = 874192451,
      content,
      systemInstruction,
      contextLimit = 15,
      temperature = 0.7,
    } = req.body;

    if (!content || typeof content !== 'string') {
      return res.status(400).json({ error: 'Поле content обязательно' });
    }

    const trimmed = content.trim();

    // Check for /clear
    if (trimmed === '/clear') {
      const deletedCount = await dbService.clearChatHistory(chat_id);
      return res.json({
        type: 'clear',
        message: 'Контекст очищен',
        deletedCount,
      });
    }

    // Check for /start
    if (trimmed === '/start') {
      const userMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'user',
        content: '/start',
      });

      const startReply =
        '👋 Привет! Я AI-ассистент на базе **Gemini 3.1 Flash Lite** с сохранением контекста в **PostgreSQL**.\n\n' +
        '• 💬 Отвечаю на вопросы и помню историю диалога\n' +
        '• 🎨 Генерирую картинки: `/image <описание>`\n' +
        '• 🧹 Очистить контекст: `/clear`\n' +
        '• 📊 Статистика: `/stats`';

      const botMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'model',
        content: startReply,
        latency_ms: 50,
      });

      return res.json({
        type: 'start',
        userMessage: userMsg,
        botMessage: botMsg,
      });
    }

    // Check for /stats
    if (trimmed === '/stats') {
      const chatMsgs = await dbService.getMessages(chat_id);
      const userMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'user',
        content: '/stats',
      });

      const statsReply =
        `📊 **Статистика диалога:**\n\n` +
        `• Всего сообщений в базе данных: ${chatMsgs.length}\n` +
        `• Используемая модель: \`gemini-3.1-flash-lite\`\n` +
        `• Хранилище: ${dbService.isUsingRealPostgres() ? 'Внешний PostgreSQL' : 'Встроенный PostgreSQL эмулятор'}`;

      const botMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'model',
        content: statsReply,
        latency_ms: 40,
      });

      return res.json({
        type: 'stats',
        userMessage: userMsg,
        botMessage: botMsg,
      });
    }

    // Check for /image or drawing commands
    const isImageReq = trimmed.startsWith('/image') || /^(нарисуй|создай картинку|сгенерируй фото|draw):?\s*(.+)/i.test(trimmed);
    if (isImageReq) {
      let prompt = trimmed.replace(/^\/image\s*/i, '').trim();
      const match = trimmed.match(/^(нарисуй|создай картинку|сгенерируй фото|draw):?\s*(.+)/i);
      if (match && match[2]) {
        prompt = match[2].trim();
      }

      if (!prompt) {
        return res.status(400).json({ error: 'Укажите промпт для генерации изображения' });
      }

      const userMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'user',
        content: trimmed,
      });

      const { base64Image, latencyMs } = await generateGeminiImage(prompt);
      const imageUrl = `data:image/png;base64,${base64Image}`;

      await dbService.saveGeneratedImage({
        chat_id,
        user_id,
        prompt,
        image_data: imageUrl,
      });

      const botMsg = await dbService.saveMessage({
        chat_id,
        user_id,
        role: 'model',
        content: `🎨 Сгенерировано изображение по запросу: «${prompt}»`,
        image_url: imageUrl,
        latency_ms: latencyMs,
      });

      return res.json({
        type: 'image',
        userMessage: userMsg,
        botMessage: botMsg,
        latencyMs,
      });
    }

    // Standard conversation with context
    // Save user message in PostgreSQL
    const userMsg = await dbService.saveMessage({
      chat_id,
      user_id,
      role: 'user',
      content: trimmed,
    });

    // Fetch prior context from PostgreSQL
    const recentHistory = await dbService.getRecentMessages(chat_id, contextLimit);

    // Call Gemini 3.1 Flash Lite
    const { text, tokenCount, latencyMs } = await askGeminiFlashLite(
      recentHistory,
      trimmed,
      {
        systemInstruction: systemInstruction || DEFAULT_SYSTEM_INSTRUCTION,
        temperature,
      }
    );

    // Save model response in PostgreSQL
    const botMsg = await dbService.saveMessage({
      chat_id,
      user_id,
      role: 'model',
      content: text,
      token_count: tokenCount,
      latency_ms: latencyMs,
    });

    return res.json({
      type: 'text',
      userMessage: userMsg,
      botMessage: botMsg,
      contextUsedCount: recentHistory.length,
      latencyMs,
    });
  } catch (err: any) {
    console.error('Chat API Error:', err);
    res.status(500).json({ error: err.message || 'Ошибка обработки сообщения' });
  }
});

// 3. Image Generation standalone API
app.post('/api/generate-image', async (req: Request, res: Response) => {
  try {
    const { prompt, chat_id = 874192451, user_id = 874192451 } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Промпт не указан' });
    }

    const { base64Image, latencyMs } = await generateGeminiImage(prompt);
    const imageUrl = `data:image/png;base64,${base64Image}`;

    const saved = await dbService.saveGeneratedImage({
      chat_id,
      user_id,
      prompt,
      image_data: imageUrl,
    });

    res.json({
      success: true,
      image: saved,
      latencyMs,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Ошибка генерации изображения' });
  }
});

// 4. Chats and messages
app.get('/api/chats', async (req: Request, res: Response) => {
  const chats = await dbService.getChats();
  res.json(chats);
});

app.get('/api/chats/:id/messages', async (req: Request, res: Response) => {
  const chatId = parseInt(req.params.id, 10);
  const messages = await dbService.getMessages(chatId);
  res.json(messages);
});

app.delete('/api/chats/:id/messages', async (req: Request, res: Response) => {
  const chatId = parseInt(req.params.id, 10);
  const count = await dbService.clearChatHistory(chatId);
  res.json({ success: true, count });
});

// 5. Bot stats
app.get('/api/stats', async (req: Request, res: Response) => {
  const stats = await dbService.getStats();
  res.json(stats);
});

// 6. Database SQL runner & table inspection
app.post('/api/db/query', async (req: Request, res: Response) => {
  try {
    const { sql } = req.body;
    if (!sql || typeof sql !== 'string') {
      return res.status(400).json({ error: 'Параметр sql обязателен' });
    }
    const result = await dbService.executeSql(sql);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/db/tables', async (req: Request, res: Response) => {
  const users = await dbService.getAllUsers();
  const chats = await dbService.getChats();
  const messages = await dbService.getAllMessages();
  const images = await dbService.getAllImages();

  res.json({
    tables: [
      { name: 'tg_messages', rowCount: messages.length, description: 'История сообщений и контекст для LLM' },
      { name: 'tg_chats', rowCount: chats.length, description: 'Чаты (личные диалоги и группы)' },
      { name: 'tg_users', rowCount: users.length, description: 'Пользователи Telegram' },
      { name: 'image_generations', rowCount: images.length, description: 'Сгенерированные изображения' },
    ],
    sampleData: {
      tg_messages: messages.slice(0, 15),
      tg_chats: chats,
      tg_users: users,
      image_generations: images.slice(0, 10),
    },
  });
});

// 7. Standalone Code Templates for Export
app.get('/api/code/templates', (req: Request, res: Response) => {
  res.json(CODE_TEMPLATES);
});

// 8. Telegram Bot Token & Polling Management
app.get('/api/telegram/status', (req: Request, res: Response) => {
  res.json(telegramManager.getStatus());
});

app.post('/api/telegram/start-polling', async (req: Request, res: Response) => {
  const { token } = req.body;
  const result = await telegramManager.startPolling(token);
  res.json(result);
});

app.post('/api/telegram/stop-polling', async (req: Request, res: Response) => {
  const result = await telegramManager.stopPolling();
  res.json(result);
});

// Telegram Webhook endpoint (if user sets webhook on their domain)
app.post('/api/telegram/webhook', async (req: Request, res: Response) => {
  try {
    const update = req.body;
    // Process update asynchronously so Telegram gets instant 200 OK
    telegramManager.handleUpdate(update).catch((err) => {
      console.error('Webhook error:', err);
    });
    res.json({ ok: true });
  } catch (err) {
    res.json({ ok: true });
  }
});

// Vite Middleware for Development / Static files for Production
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Telegram Bot Suite Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(console.error);
